print("Hello world")

x = 4;
y = 6;

z = x + y;

print(z);
